import React from "react";
import DailyWorkReminderApp from "./DailyWorkReminderApp";

export default function App() {
  return <DailyWorkReminderApp />;
}
